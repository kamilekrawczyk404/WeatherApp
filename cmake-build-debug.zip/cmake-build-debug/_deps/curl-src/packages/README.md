<!--
Copyright (C) Daniel Stenberg, <daniel@haxx.se>, et al.

SPDX-License-Identifier: curl
-->

# Packages

 This directory and all its subdirectories are for special package
information, templates, scripts and docs. The files herein should be of use
for those of you who want to package curl in a binary or source format for
these platforms.
